# Pyarmor 8.5.12 (trial), 000000, 2024-10-14T21:03:27.572621
from .pyarmor_runtime import __pyarmor__
